<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('main'); #default action
//App::getRouter()->setLoginRoute('signinShow'); #action to forward if no permissions

Utils::addRoute('hello', 'HelloCtrl');
//Utils::addRoute('action_name', 'controller_class_name');

Utils::addRoute('produkt', 'ProduktCtrl');
Utils::addRoute('dodajprodukt', 'ProduktCtrl');
Utils::addRoute('profil', 'ProfilCtrl');
Utils::addRoute('edycjaprofilu', 'ProfilCtrl');
Utils::addRoute('dodajAdres', 'ProfilCtrl');
Utils::addRoute('zapiszEdycjeProfilu', 'ProfilCtrl');
Utils::addRoute('main', 'MainCtrl');
Utils::addRoute('koszyk', 'KoszykCtrl');
Utils::addRoute('usunzkoszyk', 'KoszykCtrl');
Utils::addRoute('ustalilosc', 'KoszykCtrl');
Utils::addRoute('zlozzamowienie', 'KoszykCtrl');
Utils::addRoute('signupShow', 'SignupCtrl');
Utils::addRoute('signinShow', 'SigninCtrl');
Utils::addRoute('signin', 'SigninCtrl');
Utils::addRoute('signup', 'SignupCtrl');
Utils::addRoute('signout', 'SigninCtrl');
Utils::addRoute('addProduct', 'ProductCtrl', ["pracownik"]);
Utils::addRoute('panelPrac', 'PanelPracCtrl', ["pracownik"]);
Utils::addRoute('dodajProdukt', 'PanelPracCtrl', ["pracownik"]);
Utils::addRoute('usunProdukt', 'PanelPracCtrl', ["pracownik"]);
Utils::addRoute('dodajAutora', 'PanelPracCtrl', ["pracownik"]);
Utils::addRoute('adminPanel', 'AdminCtrl', ["admin"]);
Utils::addRoute('dodajUzytkownika', 'AdminCtrl', ["admin"]);
Utils::addRoute('usunUzytkownika', 'AdminCtrl', ["admin"]);
Utils::addRoute('dodajRole', 'AdminCtrl', ["admin"]);
Utils::addRoute('usunRole', 'AdminCtrl', ["admin"]);
Utils::addRoute('zamowienieShow', 'KoszykCtrl');

