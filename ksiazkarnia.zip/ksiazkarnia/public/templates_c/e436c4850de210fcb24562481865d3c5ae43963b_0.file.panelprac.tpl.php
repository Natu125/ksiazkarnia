<?php
/* Smarty version 4.3.4, created on 2024-05-25 03:05:01
  from 'D:\xampp\htdocs\amelia\app\views\templates\Domainer\panelprac.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6651393da83cb3_02178198',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e436c4850de210fcb24562481865d3c5ae43963b' => 
    array (
      0 => 'D:\\xampp\\htdocs\\amelia\\app\\views\\templates\\Domainer\\panelprac.tpl',
      1 => 1716599068,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6651393da83cb3_02178198 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "Domainer/index.tpl");
}
}
