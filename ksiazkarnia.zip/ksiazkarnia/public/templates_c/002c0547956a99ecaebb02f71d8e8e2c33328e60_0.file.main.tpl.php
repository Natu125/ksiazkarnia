<?php
/* Smarty version 4.3.4, created on 2024-06-08 16:12:42
  from 'D:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_666466da9b8528_27174361',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '002c0547956a99ecaebb02f71d8e8e2c33328e60' => 
    array (
      0 => 'D:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\main.tpl',
      1 => 1717855955,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_666466da9b8528_27174361 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_232165874666466da98a6a9_32389074', 'menu');
?>


	<!-- CONTENT -->
	<!-- TODO: Change content in the rows/columns below 
	     Please note, 24-columns grid is used in the template, so you can reorder the blocks 
	     to make, for example, 2-columns layout (use a pair of col span_12) or 4-column one
	     (use 4 copies of col span_6) -->
	
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1016345570666466da98c173_37079923', 'content');
?>

		
<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "Domainer/index.tpl");
}
/* {block 'menu'} */
class Block_232165874666466da98a6a9_32389074 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'menu' => 
  array (
    0 => 'Block_232165874666466da98a6a9_32389074',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	
	<!-- END OF STATS LINE  -->
<?php
}
}
/* {/block 'menu'} */
/* {block 'content'} */
class Block_1016345570666466da98c173_37079923 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1016345570666466da98c173_37079923',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		 <!-- end of row -->

		<hr class="divider">

		<div class="row padding">
			


			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['elements']->value, 'element');
$_smarty_tpl->tpl_vars['element']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['element']->value) {
$_smarty_tpl->tpl_vars['element']->do_else = false;
?>
    <div class="col span_4">
        <p class="align-center">
            <a class="sample-banner" style="width:150px; height:200px; line-height:125px;" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
produkt?produktid=<?php echo $_smarty_tpl->tpl_vars['element']->value['id_produktu'];?>
">
                <img src="/ksiazkarnia/public/images/product_images/<?php echo $_smarty_tpl->tpl_vars['element']->value['obrazek'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['element']->value['nazwa'];?>
" style="width:100%; height:100%; ">
            </a>
            <br>
            <?php echo $_smarty_tpl->tpl_vars['element']->value['nazwa'];?>

        </p>
    </div>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

		</div> <!-- end of row -->
		
		<hr class="divider">
	<?php
}
}
/* {/block 'content'} */
}
