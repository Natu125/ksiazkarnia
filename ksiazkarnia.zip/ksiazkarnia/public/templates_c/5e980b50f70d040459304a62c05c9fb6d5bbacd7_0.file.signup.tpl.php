<?php
/* Smarty version 4.3.4, created on 2024-05-25 16:39:49
  from 'D:\xampp\htdocs\amelia\app\views\templates\Domainer\signup.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6651f835311141_42741689',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5e980b50f70d040459304a62c05c9fb6d5bbacd7' => 
    array (
      0 => 'D:\\xampp\\htdocs\\amelia\\app\\views\\templates\\Domainer\\signup.tpl',
      1 => 1716647746,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6651f835311141_42741689 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8899745686651f83530b5f8_87510485', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_8899745686651f83530b5f8_87510485 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_8899745686651f83530b5f8_87510485',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Rejestracja</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Załóż nowe konto</h3>
							<p class="text-center text-muted">Masz już konto? <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
signin">Zaloguj się</a>  </p>
							<hr>

							<form>
								<div class="top-margin">
									<label>Imię</label>
									<input type="text" class="form-control">
								</div>
								<div class="top-margin">
									<label>Nazwisko</label>
									<input type="text" class="form-control">
								</div>
								<div class="top-margin">
									<label>Email <span class="text-danger">*</span></label>
									<input type="text" class="form-control">
								</div>

								<div class="row top-margin">
									<div class="col-sm-6">
										<label>Hasło <span class="text-danger">*</span></label>
										<input type="text" class="form-control">
									</div>
									<div class="col-sm-6">
										<label>Potwierdź hasło <span class="text-danger">*</span></label>
										<input type="text" class="form-control">
									</div>
								</div>

								<hr>

								<div class="row">
									
									<div class="col-lg-4 text-right">
										<button class="btn btn-action" type="submit">Zarejestruj</button>
									</div>
								</div>
							</form>
						</div>
					</div>

				</div>
				
			</article>
<?php
}
}
/* {/block 'content'} */
}
