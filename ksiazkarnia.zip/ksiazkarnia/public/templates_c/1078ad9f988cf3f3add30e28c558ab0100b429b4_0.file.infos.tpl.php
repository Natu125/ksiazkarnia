<?php
/* Smarty version 4.3.4, created on 2024-06-07 17:26:30
  from 'D:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\infos.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_666326a66c22e0_72949312',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1078ad9f988cf3f3add30e28c558ab0100b429b4' => 
    array (
      0 => 'D:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\infos.tpl',
      1 => 1717458773,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_666326a66c22e0_72949312 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1715657048666326a66b5d63_90410840', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1941095105666326a66c16f4_34868096', 'messages');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_1715657048666326a66b5d63_90410840 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1715657048666326a66b5d63_90410840',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<article class="col-xs-12 maincontent">
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<?php if ((isset($_smarty_tpl->tpl_vars['infos']->value))) {?>
								<?php echo $_smarty_tpl->tpl_vars['infos']->value;?>

							<?php }?>
                        </div>

								<hr>

								<div class="row">
									
									<div class="col-lg-4 text-right">
										<li><a class="btn" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
main">Przejdź do strony głównej</a></li>
									</div>
								</div>
							</form>
						</div>
					</div>

				</div>
				
			</article>
<?php
}
}
/* {/block 'content'} */
/* {block 'messages'} */
class Block_1941095105666326a66c16f4_34868096 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_1941095105666326a66c16f4_34868096',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'messages'} */
}
