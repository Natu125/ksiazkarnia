<?php
/* Smarty version 4.3.4, created on 2024-05-25 02:59:12
  from 'D:\xampp\htdocs\amelia\app\views\templates\Domainer\koszyk.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_665137e022b851_33233174',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e0fb95573509a3b3837d57448d6bb00b7fc94dc4' => 
    array (
      0 => 'D:\\xampp\\htdocs\\amelia\\app\\views\\templates\\Domainer\\koszyk.tpl',
      1 => 1716598675,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_665137e022b851_33233174 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "Domainer/index.tpl");
}
}
