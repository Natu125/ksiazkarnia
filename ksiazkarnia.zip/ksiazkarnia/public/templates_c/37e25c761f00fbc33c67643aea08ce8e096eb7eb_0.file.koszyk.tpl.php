<?php
/* Smarty version 4.3.4, created on 2024-06-11 03:03:55
  from 'D:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\koszyk.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6667a27b9bc025_47560436',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '37e25c761f00fbc33c67643aea08ce8e096eb7eb' => 
    array (
      0 => 'D:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\koszyk.tpl',
      1 => 1718066690,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6667a27b9bc025_47560436 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13045873186667a27b9a1c91_14799714', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "Domainer/index.tpl");
}
/* {block 'content'} */
class Block_13045873186667a27b9a1c91_14799714 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_13045873186667a27b9a1c91_14799714',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'D:\\xampp\\htdocs\\ksiazkarnia\\lib\\smarty\\plugins\\modifier.count.php','function'=>'smarty_modifier_count',),));
?>

    <div class="row special">
        <div class="col span_24">
            <h3 class="align-center">
                <h1>Koszyk</h1>
                <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
                    <div class="messages bottom-margin">
                        <ul>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                                <li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </ul>
                    </div>
                <?php }?>
                <?php if (smarty_modifier_count($_smarty_tpl->tpl_vars['cart_items']->value) > 0) {?>
                    <?php if ($_smarty_tpl->tpl_vars['has_address']->value) {?>
                        <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
zlozzamowienie" method="post">
                            <input type="submit" value="Złóż zamówienie">
                        </form>
                    <?php } else { ?>
                        <p>Aby złożyć zamówienie, dodaj adres dostawy.</p>
                    <?php }?>
                    <ul>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cart_items']->value, 'product');
$_smarty_tpl->tpl_vars['product']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['product']->value) {
$_smarty_tpl->tpl_vars['product']->do_else = false;
?>
                            <li>
                                <?php echo $_smarty_tpl->tpl_vars['product']->value['name'];?>
 - <?php echo $_smarty_tpl->tpl_vars['product']->value['price'];?>
 PLN
                                <br>Dostępność: <?php echo $_smarty_tpl->tpl_vars['product']->value['availability'];?>
 sztuk
                                <br>Łączna cena: <?php echo $_smarty_tpl->tpl_vars['product']->value['total_price'];?>
 PLN
                                <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
ustalilosc" method="post" style="display:inline;">
                                    <input type="hidden" name="product_id" value="<?php echo $_smarty_tpl->tpl_vars['product']->value['id'];?>
">
                                    <input type="number" name="quantity" value="<?php echo (($tmp = $_smarty_tpl->tpl_vars['product']->value['quantity'] ?? null)===null||$tmp==='' ? 1 ?? null : $tmp);?>
" min="1" max="<?php echo $_smarty_tpl->tpl_vars['product']->value['availability'];?>
" style="width: 50px;">
                                    <input type="submit" value="Zaktualizuj ilość">
                                </form>
                                <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
usunzkoszyk" method="post" style="display:inline;">
                                    <input type="hidden" name="product_id" value="<?php echo $_smarty_tpl->tpl_vars['product']->value['id'];?>
">
                                    <input type="submit" value="Usuń z koszyka">
                                </form>
                            </li>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </ul>
                    <div>
                        <strong>Łączna kwota zamówienia: <?php echo $_smarty_tpl->tpl_vars['total_price']->value;?>
 PLN</strong>
                    </div>
                <?php } else { ?>
                    <p>Twój koszyk jest pusty.</p>
                <?php }?>
            </h3>
        </div>
    </div>
<?php
}
}
/* {/block 'content'} */
}
