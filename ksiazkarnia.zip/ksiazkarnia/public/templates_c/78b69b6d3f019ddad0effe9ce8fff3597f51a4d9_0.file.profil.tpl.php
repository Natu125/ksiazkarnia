<?php
/* Smarty version 4.3.4, created on 2024-06-10 16:02:13
  from 'C:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\profil.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66670765c702b7_15141018',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '78b69b6d3f019ddad0effe9ce8fff3597f51a4d9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\profil.tpl',
      1 => 1717801472,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66670765c702b7_15141018 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_189858773766670765c1d237_57349820', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_21196303266670765c6fda3_38580373', 'messages');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_189858773766670765c1d237_57349820 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_189858773766670765c1d237_57349820',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<article class="col-xs-12 maincontent">
    <header class="page-header">
        <h1 class="page-title">Profil użytkownika</h1>
    </header>

    <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
        <div class="panel panel-default">
            <div class="panel-body">
                <h2 class="thin text-center">Twoje dane</h2>
                <hr>

                <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
                    <div class="messages bottom-margin">
                        <ul>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                                <li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </ul>
                    </div>
                <?php }?>

                <h2>Imię: <?php echo $_smarty_tpl->tpl_vars['imie']->value;?>
</h2>
                <h2>Nazwisko: <?php echo $_smarty_tpl->tpl_vars['nazwisko']->value;?>
</h2>
                <h2>Email: <?php echo $_smarty_tpl->tpl_vars['email']->value;?>
</h2>
                <h2>Adres:</h2>
                <p>
                    <?php if ((isset($_smarty_tpl->tpl_vars['kraj']->value))) {?>
                        <?php echo $_smarty_tpl->tpl_vars['kraj']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['miejscowosc']->value;?>
, <?php echo $_smarty_tpl->tpl_vars['ulica_i_lokal']->value;?>

                    <?php } else { ?>
                        Adres nie został ustawiony.
                    <?php }?>
                </p>

                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav pull-right">
                        <li><a class="btn" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
edycjaprofilu">Edytuj profil</a></li>
                    </ul>
                </div>

                <hr>
                <h2 class="thin text-center">Twoje zamówienia</h2>
                <div>
                    <?php $_smarty_tpl->_assignInScope('order_number', 1);?>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['orders']->value, 'order');
$_smarty_tpl->tpl_vars['order']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['order']->value) {
$_smarty_tpl->tpl_vars['order']->do_else = false;
?>
                        <div class="order">
                            <h3>Zamówienie nr: <?php echo $_smarty_tpl->tpl_vars['order_number']->value;?>
</h3>
                            <p>Data: <?php echo $_smarty_tpl->tpl_vars['order']->value['data'];?>
</p>
                            <p>Suma: <?php echo $_smarty_tpl->tpl_vars['order']->value['suma'];?>
 PLN</p>
                            <h4>Produkty:</h4>
                            <ul>
                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['order']->value['produkty'], 'produkt');
$_smarty_tpl->tpl_vars['produkt']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['produkt']->value) {
$_smarty_tpl->tpl_vars['produkt']->do_else = false;
?>
                                    <li>
                                        <strong>Nazwa:</strong> <?php echo $_smarty_tpl->tpl_vars['produkt']->value['nazwa'];?>
 <br>
                                        <strong>Cena:</strong> <?php echo $_smarty_tpl->tpl_vars['produkt']->value['cena'];?>
 PLN <br>
                                        <strong>Ilość:</strong> <?php echo $_smarty_tpl->tpl_vars['produkt']->value['ilosc'];?>
 <br>
                                        <strong>Kwota:</strong> <?php echo $_smarty_tpl->tpl_vars['produkt']->value['kwota'];?>
 PLN
                                    </li>
                                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                            </ul>
                        </div>
                        <hr>
                        <?php $_smarty_tpl->_assignInScope('order_number', $_smarty_tpl->tpl_vars['order_number']->value+1);?>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </div>

            </div>
        </div>
    </div>
</article>
<?php
}
}
/* {/block 'content'} */
/* {block 'messages'} */
class Block_21196303266670765c6fda3_38580373 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_21196303266670765c6fda3_38580373',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'messages'} */
}
