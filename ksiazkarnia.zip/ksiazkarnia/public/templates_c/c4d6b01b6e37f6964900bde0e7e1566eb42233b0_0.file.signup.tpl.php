<?php
/* Smarty version 4.3.4, created on 2024-05-31 21:58:24
  from 'D:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\signup.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_665a2be0767e33_60485292',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c4d6b01b6e37f6964900bde0e7e1566eb42233b0' => 
    array (
      0 => 'D:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\signup.tpl',
      1 => 1717185423,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_665a2be0767e33_60485292 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_494956704665a2be073f9e5_50100163', 'content');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_354689874665a2be0767020_02682252', 'messages');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_494956704665a2be073f9e5_50100163 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_494956704665a2be073f9e5_50100163',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<article class="col-xs-12 maincontent">
    <header class="page-header">
        <h1 class="page-title">Rejestracja</h1>
    </header>
    
    <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
        <div class="panel panel-default">
            <div class="panel-body">
                <h3 class="thin text-center">Załóż nowe konto</h3>
                <p class="text-center text-muted">Masz już konto? <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
signinShow">Zaloguj się</a></p>
                <hr>

                <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
                    <div class="messages bottom-margin">
                    <ul>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                        <li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </ul>
                    </div>
                <?php }?>

                <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
signup" method="post">
                    <div class="top-margin">
                        <label>Imię</label>
                        <input type="text" name="firstname" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['form']->value->firstname, ENT_QUOTES, 'UTF-8', true);?>
" class="form-control">
                    </div>
                    <div class="top-margin">
                        <label>Nazwisko</label>
                        <input type="text" name="lastname" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['form']->value->lastname, ENT_QUOTES, 'UTF-8', true);?>
" class="form-control">
                    </div>
                    <div class="top-margin">
                        <label>Email <span class="text-danger">*</span></label>
                        <input type="text" name="username" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['form']->value->username, ENT_QUOTES, 'UTF-8', true);?>
" class="form-control" required>
                    </div>

                    <div class="row top-margin">
                        <div class="col-sm-6">
                            <label>Hasło <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-sm-6">
                            <label>Potwierdź hasło <span class="text-danger">*</span></label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="col-lg-4 col-lg-offset-8 text-right">
                            <button class="btn btn-action" type="submit">Zarejestruj</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</article>
<?php
}
}
/* {/block 'content'} */
/* {block 'messages'} */
class Block_354689874665a2be0767020_02682252 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_354689874665a2be0767020_02682252',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'messages'} */
}
