<?php
/* Smarty version 4.3.4, created on 2024-05-24 14:56:03
  from 'D:\xampp\htdocs\amelia\app\views\templates\Domainer\profil.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66508e633b2785_35709152',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '671b405cbae6428a0dea2a0be3067950bd78bd48' => 
    array (
      0 => 'D:\\xampp\\htdocs\\amelia\\app\\views\\templates\\Domainer\\profil.tpl',
      1 => 1716555324,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66508e633b2785_35709152 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9633750666508e633b0df8_40579018', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/main.tpl");
}
/* {block 'content'} */
class Block_9633750666508e633b0df8_40579018 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_9633750666508e633b0df8_40579018',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="row special">
		<div class="col span_24">
			<h3 class="align-center">Having owned this domain since 2001, I'm moving on to other projects and would like to sell it. 
				Feel free to contact if interested. Thanks.</h3>
		</div>
	</div>

	
	<div class="row padding">
		<div class="col span_8">
			<div class="circle"><i class="icon icon-support"></i></div>
			<h3 class="align-center">Easy to remember domain</h3>
			<p class="align-center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh 
				euismod tincidunt ut laoreet dolore magna.</p>
		</div>

		<div class="col span_8">
			<div class="circle"><i class="icon icon-stockup"></i></div>
			<h3 class="align-center">Awesome stats</h3>
			<p class="align-center">Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, 
				vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio.</p>
		</div>

		<div class="col span_8">
			<div class="circle"><i class="icon icon-briefcase"></i></div>
			<h3 class="align-center">Popularity</h3>
			<p class="align-center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod 
				tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam.</p>
		</div>
	</div> <!-- end of row -->

	<hr class="divider">

	<div class="row padding">
		<div class="col span_4">
			 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
		</div>
		<div class="col span_4">
			 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
		</div>
		<div class="col span_4">
			 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
		</div>
		<div class="col span_4">
			 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
		</div>
		<div class="col span_4">
			 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
		</div>
		<div class="col span_4">
			 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
		</div>
	</div> <!-- end of row -->
	
	<hr class="divider">
<?php
}
}
/* {/block 'content'} */
}
