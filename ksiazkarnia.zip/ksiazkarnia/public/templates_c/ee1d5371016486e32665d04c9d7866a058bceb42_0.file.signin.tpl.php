<?php
/* Smarty version 4.3.4, created on 2024-05-25 16:39:39
  from 'D:\xampp\htdocs\amelia\app\views\templates\Domainer\signin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6651f82bda3095_86398878',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ee1d5371016486e32665d04c9d7866a058bceb42' => 
    array (
      0 => 'D:\\xampp\\htdocs\\amelia\\app\\views\\templates\\Domainer\\signin.tpl',
      1 => 1716647975,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6651f82bda3095_86398878 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7927808146651f82bd9ba70_39849956', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_7927808146651f82bd9ba70_39849956 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_7927808146651f82bd9ba70_39849956',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Logowanie</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Zaloguj się</h3>
							<p class="text-center text-muted">Nie masz jeszcze konta? <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
signup">Zarejestruj się</a>  </p>
							<hr>
							
							<form>
								<div class="top-margin">
									<label>Email <span class="text-danger">*</span></label>
									<input type="text" class="form-control">
								</div>
								<div class="top-margin">
									<label>Hasło <span class="text-danger">*</span></label>
									<input type="password" class="form-control">
								</div>

								<hr>

								<div class="row">
									
									<div class="col-lg-4 text-right">
										<button class="btn btn-action" type="submit">Zaloguj</button>
									</div>
								</div>
							</form>
						</div>
					</div>

				</div>
				
			</article>
<?php
}
}
/* {/block 'content'} */
}
