<?php
/* Smarty version 4.3.4, created on 2024-06-11 03:15:15
  from 'D:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\panelprac.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6667a52349b1f6_66023251',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8dfc8c80f114d596b5eb14f7fde5acec15d638ad' => 
    array (
      0 => 'D:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\panelprac.tpl',
      1 => 1718068509,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6667a52349b1f6_66023251 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9983985986667a523489824_98417841', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17574829946667a52349acb2_04612384', 'messages');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_9983985986667a523489824_98417841 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_9983985986667a523489824_98417841',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1>Admin Panel</h1>
    
    <!-- Formularz dodawania produktu -->
    <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
dodajProdukt" method="post">
        <h2>Dodaj Produkt</h2>
        <label>Nazwa: <input type="text" name="nazwa" required></label>
        <label>Cena: <input type="number" name="cena" required></label>
        <label>Opis: <textarea name="opis" required></textarea></label>
        <label>Dostępność: <input type="number" name="dostepnosc" required></label>
        <label>Obrazek: <input type="text" name="obrazek" required></label>
        <label>Autor: 
            <select name="id_autora" required>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['authors']->value, 'author');
$_smarty_tpl->tpl_vars['author']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['author']->value) {
$_smarty_tpl->tpl_vars['author']->do_else = false;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['author']->value['id_autora'];?>
"><?php echo $_smarty_tpl->tpl_vars['author']->value['imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['author']->value['nazwisko'];?>
</option>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </select>
        </label>
        <button type="submit">Dodaj Produkt</button>
    </form>

    <!-- Formularz dodawania autora -->
    <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
dodajAutora" method="post">
        <h2>Dodaj Autora</h2>
        <label>Imię: <input type="text" name="imie" required></label>
        <label>Nazwisko: <input type="text" name="nazwisko" required></label>
        <button type="submit">Dodaj Autora</button>
    </form>

    <!-- Lista produktów z opcjami edycji i usuwania -->
    <h2>Produkty</h2>
    <table>
        <thead>
            <tr>
                <th>Nazwa</th>
                <th>Cena</th>
                <th>Opis</th>
                <th>Dostępność</th>
                <th>Obrazek</th>
                <th>Autor</th>
                <th>Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['products']->value, 'product');
$_smarty_tpl->tpl_vars['product']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['product']->value) {
$_smarty_tpl->tpl_vars['product']->do_else = false;
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['product']->value['nazwa'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['product']->value['cena'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['product']->value['opis'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['product']->value['dostepnosc'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['product']->value['obrazek'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['product']->value['id_autora'];?>
</td>
                    <td>
                        <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
usunProdukt" method="post" style="display:inline;">
                            <input type="hidden" name="id_produktu" value="<?php echo $_smarty_tpl->tpl_vars['product']->value['id_produktu'];?>
">
                            <button type="submit">Usuń</button>
                        </form>
                    </td>
                </tr>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>

    <!-- Lista autorów z opcjami edycji i usuwania -->
    <h2>Autorzy</h2>
    <table>
        <thead>
            <tr>
                <th>Imię</th>
                <th>Nazwisko</th>
                <th>Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['authors']->value, 'author');
$_smarty_tpl->tpl_vars['author']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['author']->value) {
$_smarty_tpl->tpl_vars['author']->do_else = false;
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['author']->value['imie'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['author']->value['nazwisko'];?>
</td>
                    <td>
                        <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
usunAutora" method="post" style="display:inline;">
                            <input type="hidden" name="id_autora" value="<?php echo $_smarty_tpl->tpl_vars['author']->value['id_autora'];?>
">
                            <button type="submit">Usuń</button>
                        </form>
                    </td>
                </tr>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>
<?php
}
}
/* {/block 'content'} */
/* {block 'messages'} */
class Block_17574829946667a52349acb2_04612384 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_17574829946667a52349acb2_04612384',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'messages'} */
}
