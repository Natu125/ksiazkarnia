<?php
/* Smarty version 4.3.4, created on 2024-06-04 01:54:10
  from 'C:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\infos.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_665e57a2768f01_06203843',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ab7d77cfe417c9f8467ba7316c548cd0e214684d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\infos.tpl',
      1 => 1717458773,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_665e57a2768f01_06203843 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_336700983665e57a2764a06_41825659', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1653523965665e57a27689d9_78965118', 'messages');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_336700983665e57a2764a06_41825659 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_336700983665e57a2764a06_41825659',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<article class="col-xs-12 maincontent">
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<?php if ((isset($_smarty_tpl->tpl_vars['infos']->value))) {?>
								<?php echo $_smarty_tpl->tpl_vars['infos']->value;?>

							<?php }?>
                        </div>

								<hr>

								<div class="row">
									
									<div class="col-lg-4 text-right">
										<li><a class="btn" href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
main">Przejdź do strony głównej</a></li>
									</div>
								</div>
							</form>
						</div>
					</div>

				</div>
				
			</article>
<?php
}
}
/* {/block 'content'} */
/* {block 'messages'} */
class Block_1653523965665e57a27689d9_78965118 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_1653523965665e57a27689d9_78965118',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'messages'} */
}
