<?php
/* Smarty version 4.3.4, created on 2024-06-11 03:08:35
  from 'D:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\signin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6667a393adebc7_06307966',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9164334275630e36f6d302aed16d9cf544db09e0' => 
    array (
      0 => 'D:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\signin.tpl',
      1 => 1718067040,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6667a393adebc7_06307966 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_18539371806667a393acca43_20600910', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3115274106667a393ade676_95281989', 'messages');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_18539371806667a393acca43_20600910 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_18539371806667a393acca43_20600910',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<article class="col-xs-12 maincontent">
    <header class="page-header">
        <h1 class="page-title">Logowanie</h1>
    </header>
    
    <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
        <div class="panel panel-default">
            <div class="panel-body">
                <h3 class="thin text-center">Zaloguj się</h3>
                <p class="text-center text-muted">Nie masz jeszcze konta? <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
signup">Zarejestruj się</a></p>
                <hr>
                <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
                    <div class="messages bottom-margin">
                        <ul>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                            <li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </ul>
                    </div>
                <?php }?>
                <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
signin" method="post">
                    <div class="top-margin">
                        <label>Email <span class="text-danger">*</span></label>
                        <input type="text" name="username" value="<?php echo htmlspecialchars((string)$_smarty_tpl->tpl_vars['form']->value->username, ENT_QUOTES, 'UTF-8', true);?>
" class="form-control">
                    </div>
                    <div class="top-margin">
                        <label>Hasło <span class="text-danger">*</span></label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-4 text-right">
                            <button class="btn btn-action" type="submit">Zaloguj</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</article>
<?php
}
}
/* {/block 'content'} */
/* {block 'messages'} */
class Block_3115274106667a393ade676_95281989 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_3115274106667a393ade676_95281989',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'messages'} */
}
