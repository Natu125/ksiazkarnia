<?php
/* Smarty version 4.3.4, created on 2024-06-11 03:15:50
  from 'D:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\adminPanel.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6667a546b80c21_74037949',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4ae74a58ded8468d6c792351e946e5b814cd2774' => 
    array (
      0 => 'D:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\adminPanel.tpl',
      1 => 1718044694,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6667a546b80c21_74037949 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1983302906667a546b678a7_11677643', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11648035096667a546b806c8_14605736', 'messages');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_1983302906667a546b678a7_11677643 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1983302906667a546b678a7_11677643',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h1>Panel administracyjny</h1>

                <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
                    <div class="messages bottom-margin">
                        <ul>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                                <li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </ul>
                    </div>
                <?php }?>

    <!-- Formularz dodawania użytkownika -->
    <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
dodajUzytkownika" method="post">
        <h2>Dodaj Użytkownika</h2>

        <div class="form-group">
            <label for="imie">Imię: </label>
            <input type="text" class="form-control" id="imie" name="imie" required>
        </div>
        <div class="form-group">
            <label for="nazwisko">Nazwisko: </label>
            <input type="text" class="form-control" id="nazwisko" name="nazwisko" required>
        </div>
        <div class="form-group">
            <label for="email">Email: </label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="haslo">Hasło: </label>
            <input type="password" class="form-control" id="haslo" name="haslo" required>
        </div>
        <div class="form-group">
            <label for="kraj">Kraj: </label>
            <input type="text" class="form-control" id="kraj" name="kraj" required>
        </div>
        <div class="form-group">
            <label for="miejscowosc">Miejscowość: </label>
            <input type="text" class="form-control" id="miejscowosc" name="miejscowosc" required>
        </div>
        <div class="form-group">
            <label for="ulica_i_lokal">Ulica i Lokal: </label>
            <input type="text" class="form-control" id="ulica_i_lokal" name="ulica_i_lokal" required>
        </div>

        <button type="submit" class="btn btn-primary">Dodaj Użytkownika</button>
    </form>

    <!-- Lista użytkowników z opcjami usuwania -->
    <h2>Lista Użytkowników</h2>
    <table>
        <thead>
            <tr>
                <th>Imię</th>
                <th>Nazwisko</th>
                <th>Email</th>
                <th>Adres</th>
                <th>Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'user');
$_smarty_tpl->tpl_vars['user']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
$_smarty_tpl->tpl_vars['user']->do_else = false;
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['user']->value['imie'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['user']->value['nazwisko'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['user']->value['email'];?>
</td>
                    <td>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['addresses']->value, 'address');
$_smarty_tpl->tpl_vars['address']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['address']->value) {
$_smarty_tpl->tpl_vars['address']->do_else = false;
?>
                            <?php if ($_smarty_tpl->tpl_vars['address']->value['id_adresu_dostawy'] == $_smarty_tpl->tpl_vars['user']->value['id_adresu']) {?>
                                <?php echo $_smarty_tpl->tpl_vars['address']->value['kraj'];?>
, <?php echo $_smarty_tpl->tpl_vars['address']->value['miejscowosc'];?>
, <?php echo $_smarty_tpl->tpl_vars['address']->value['ulica_i_lokal'];?>

                            <?php }?>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </td>
                    <td>
                        <?php if ($_smarty_tpl->tpl_vars['user']->value['id_uzytkownika'] != $_smarty_tpl->tpl_vars['currentUserId']->value) {?>
                            <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
usunUzytkownika" method="post" style="display:inline;">
                                <input type="hidden" name="id_uzytkownika" value="<?php echo $_smarty_tpl->tpl_vars['user']->value['id_uzytkownika'];?>
">
                                <button type="submit">Usuń</button>
                            </form>
                        <?php } else { ?>
                            <span>Nie możesz usunąć swojego konta</span>
                        <?php }?>
                    </td>
                </tr>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>

    <!-- Formularz aktualizacji roli -->
    <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
dodajRole" method="post">
        <h2>Aktualizuj Rolę Użytkownika</h2>
        <label>Użytkownik: 
            <select name="id_uzytkownika" required>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'user');
$_smarty_tpl->tpl_vars['user']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
$_smarty_tpl->tpl_vars['user']->do_else = false;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['user']->value['id_uzytkownika'];?>
"><?php echo $_smarty_tpl->tpl_vars['user']->value['imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['user']->value['nazwisko'];?>
 (<?php echo $_smarty_tpl->tpl_vars['user']->value['email'];?>
)</option>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </select>
        </label>
        <label>Rola: 
            <select name="id_roli" required>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['roles']->value, 'role');
$_smarty_tpl->tpl_vars['role']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['role']->value) {
$_smarty_tpl->tpl_vars['role']->do_else = false;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['role']->value['id_roli'];?>
"><?php echo $_smarty_tpl->tpl_vars['role']->value['nazwa'];?>
</option>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </select>
        </label>
        <button type="submit">Aktualizuj Rolę</button>
    </form>

    <!-- Lista ról użytkowników z opcjami usuwania -->
    <h2>Role Użytkowników</h2>
    <table>
        <thead>
            <tr>
                <th>Użytkownik</th>
                <th>Rola</th>
                <th>Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['catalogs']->value, 'catalog');
$_smarty_tpl->tpl_vars['catalog']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['catalog']->value) {
$_smarty_tpl->tpl_vars['catalog']->do_else = false;
?>
                <tr>
                    <td>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['users']->value, 'user');
$_smarty_tpl->tpl_vars['user']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['user']->value) {
$_smarty_tpl->tpl_vars['user']->do_else = false;
?>
                            <?php if ($_smarty_tpl->tpl_vars['user']->value['id_uzytkownika'] == $_smarty_tpl->tpl_vars['catalog']->value['id_uzytkownika']) {?>
                                <?php echo $_smarty_tpl->tpl_vars['user']->value['imie'];?>
 <?php echo $_smarty_tpl->tpl_vars['user']->value['nazwisko'];?>
 (<?php echo $_smarty_tpl->tpl_vars['user']->value['email'];?>
)
                            <?php }?>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </td>
                    <td>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['roles']->value, 'role');
$_smarty_tpl->tpl_vars['role']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['role']->value) {
$_smarty_tpl->tpl_vars['role']->do_else = false;
?>
                            <?php if ($_smarty_tpl->tpl_vars['role']->value['id_roli'] == $_smarty_tpl->tpl_vars['catalog']->value['id_roli']) {?>
                                <?php echo $_smarty_tpl->tpl_vars['role']->value['nazwa'];?>

                            <?php }?>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </td>
                    <td>
                        <?php if ($_smarty_tpl->tpl_vars['catalog']->value['id_uzytkownika'] != $_smarty_tpl->tpl_vars['currentUserId']->value) {?>
                            <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
usunRole" method="post" style="display:inline;">
                                <input type="hidden" name="id_katalogu" value="<?php echo $_smarty_tpl->tpl_vars['catalog']->value['id_katalogu'];?>
">
                                <button type="submit">Usuń</button>
                            </form>
                        <?php } else { ?>
                            <span>Nie możesz usunąć swojej roli</span>
                        <?php }?>
                    </td>
                </tr>
            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        </tbody>
    </table>
<?php
}
}
/* {/block 'content'} */
/* {block 'messages'} */
class Block_11648035096667a546b806c8_14605736 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_11648035096667a546b806c8_14605736',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'messages'} */
}
