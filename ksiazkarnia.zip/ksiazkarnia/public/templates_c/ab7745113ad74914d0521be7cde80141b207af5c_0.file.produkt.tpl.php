<?php
/* Smarty version 4.3.4, created on 2024-05-25 03:04:57
  from 'D:\xampp\htdocs\amelia\app\views\templates\Domainer\produkt.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_66513939a79864_82552078',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ab7745113ad74914d0521be7cde80141b207af5c' => 
    array (
      0 => 'D:\\xampp\\htdocs\\amelia\\app\\views\\templates\\Domainer\\produkt.tpl',
      1 => 1716598082,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66513939a79864_82552078 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9888240166513939a77779_11693470', 'content');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_9888240166513939a77779_11693470 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_9888240166513939a77779_11693470',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<div class="row special">
		<div class="col span_24">
			<h3 class="align-center">Having owned this domain since 2001, I'm moving on to other projects and would like to sell it. 
				Feel free to contact if interested. Thanks.</h3>
		</div>
	</div>


	<div class="row padding">
		<div class="col span_8">
			<div class="circle"><i class="icon icon-support"></i></div>
			<h3 class="align-center">Easy to remember domain</h3>
			<p class="align-center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh 
				euismod tincidunt ut laoreet dolore magna.</p>
		</div>

		<div class="col span_8">
			<div class="circle"><i class="icon icon-stockup"></i></div>
			<h3 class="align-center">Awesome stats</h3>
			<p class="align-center">Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, 
				vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio.</p>
		</div>

		<div class="col span_8">
			<div class="circle"><i class="icon icon-briefcase"></i></div>
			<h3 class="align-center">Popularity</h3>
			<p class="align-center">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod 
				tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam.</p>
		</div>
	</div> <!-- end of row -->

	<hr class="divider">
<?php
}
}
/* {/block 'content'} */
}
