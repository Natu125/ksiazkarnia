<?php
/* Smarty version 4.3.4, created on 2024-06-11 03:07:47
  from 'D:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\produkt.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6667a363b7a717_06390580',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '902249ee474d7117e76de08b1afd9fc7cb786c65' => 
    array (
      0 => 'D:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\produkt.tpl',
      1 => 1718068063,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6667a363b7a717_06390580 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12727791606667a363b73700_88092702', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_12727791606667a363b73700_88092702 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_12727791606667a363b73700_88092702',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <div class="product-container">
        <div class="product-image">
            <img src="/ksiazkarnia/public/images/product_images/<?php echo $_smarty_tpl->tpl_vars['obrazek']->value;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['nazwa_produktu']->value;?>
" style="max-width:100%; height:auto;">
        </div>
        <div class="product-details">
            <h2 class="product-name"><?php echo $_smarty_tpl->tpl_vars['nazwa_produktu']->value;?>
</h2>
            <p class="product-author">Autor: <?php echo $_smarty_tpl->tpl_vars['imie_autora']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['nazwisko_autora']->value;?>
</p>
            <p class="product-availability">Dostępność: <?php echo $_smarty_tpl->tpl_vars['dostepnosc']->value;?>
</p>
            <p class="product-price">Cena: <?php echo $_smarty_tpl->tpl_vars['cena_produktu']->value;?>
 PLN</p>
            <div class="product-description">
                <h3>Opis produktu:</h3>
                <p><?php echo $_smarty_tpl->tpl_vars['opis_produktu']->value;?>
</p>
            </div>
            <div class="product-actions">
                <?php if (count($_smarty_tpl->tpl_vars['conf']->value->roles) > 0) {?>
                    <?php if ($_smarty_tpl->tpl_vars['dostepnosc']->value > 0) {?>
                        <form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
dodajprodukt" method="post">
                            <input type="hidden" name="product_id" value="<?php echo $_smarty_tpl->tpl_vars['id_produktu']->value;?>
">
                            <button type="submit" class="add-to-cart-button">Dodaj do koszyka</button>
                        </form>
                    <?php } else { ?>
                        <p class="product-availability">Brak możliwości zamówienia, produkt niedostępny</p>
                    <?php }?>
                <?php } else { ?>
                    <p>Zaloguj się, aby kupić produkt</p>
                <?php }?>
            </div>
        </div>
    </div>
<?php
}
}
/* {/block 'content'} */
}
