<?php
/* Smarty version 4.3.4, created on 2024-05-25 14:17:02
  from 'D:\xampp\htdocs\amelia\app\views\templates\Domainer\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_6651d6bed3c243_51692942',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2c0c26ee831a46b274ccb59a3923e3ac5efbbfbc' => 
    array (
      0 => 'D:\\xampp\\htdocs\\amelia\\app\\views\\templates\\Domainer\\main.tpl',
      1 => 1716599189,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6651d6bed3c243_51692942 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_14185107126651d6bed39d22_80576421', 'menu');
?>


	<!-- CONTENT -->
	<!-- TODO: Change content in the rows/columns below 
	     Please note, 24-columns grid is used in the template, so you can reorder the blocks 
	     to make, for example, 2-columns layout (use a pair of col span_12) or 4-column one
	     (use 4 copies of col span_6) -->
	
	<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_15108741226651d6bed3b8e6_59187575', 'content');
?>

		
<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "Domainer/index.tpl");
}
/* {block 'menu'} */
class Block_14185107126651d6bed39d22_80576421 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'menu' => 
  array (
    0 => 'Block_14185107126651d6bed39d22_80576421',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

	<div id="Stats" class="container">
		<div class="row">
			<div class="col span_4"><b class="value">12</b><i class="info">Domain Age</i></div>
			<div class="col span_4"><b class="value">5</b><i class="info">Google<br>Page Rank</i></div>
			<div class="col span_4"><b class="value">346</b><i class="info">Type-in<br>Daily Traffic</i></div>
			<div class="col span_4"><b class="value">N/A</b><i class="info">Alexa Rank</i></div>
			<div class="col span_4"><b class="value">146</b><i class="info">Google<br>Backlinks</i></div>
			<div class="col span_4"><b class="value">345</b><i class="info">Google<br>Indexed Pages</i></div>
		</div>
	</div>
	<!-- END OF STATS LINE  -->
<?php
}
}
/* {/block 'menu'} */
/* {block 'content'} */
class Block_15108741226651d6bed3b8e6_59187575 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_15108741226651d6bed3b8e6_59187575',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

		 <!-- end of row -->

		<hr class="divider">

		<div class="row padding">
			<div class="col span_4">
				 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
			</div>
			<div class="col span_4">
				 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
			</div>
			<div class="col span_4">
				 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
			</div>
			<div class="col span_4">
				 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
			</div>
			<div class="col span_4">
				 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
			</div>
			<div class="col span_4">
				 <p class="align-center"><a class="sample-banner" style="width:125px; height:125px; line-height:125px;" href="http://gentlethemes.com/?utm_source=Template&amp;utm_medium=Banner%2Blink&amp;utm_campaign=DomainSeller1.0">Banner</a></p>
			</div>
		</div> <!-- end of row -->
		
		<hr class="divider">
	<?php
}
}
/* {/block 'content'} */
}
