<?php
/* Smarty version 4.3.4, created on 2024-06-08 16:13:18
  from 'D:\xampp\htdocs\ksiazkarnia\app\views\templates\Domainer\edycjaprofilu.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_666466fe5a2133_32587442',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4dddb61b85573cf3dd4caca16f8b33fcb96154b3' => 
    array (
      0 => 'D:\\xampp\\htdocs\\ksiazkarnia\\app\\views\\templates\\Domainer\\edycjaprofilu.tpl',
      1 => 1717801410,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_666466fe5a2133_32587442 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_220411791666466fe5791e3_54408614', 'content');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1546255740666466fe5a1702_54538151', 'messages');
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "templates/Domainer/index.tpl");
}
/* {block 'content'} */
class Block_220411791666466fe5791e3_54408614 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_220411791666466fe5791e3_54408614',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<article class="col-xs-12 maincontent">
    <header class="page-header">
        <h1 class="page-title">Edycja profilu użytkownika</h1>
    </header>

    <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
        <div class="panel panel-default">
            <div class="panel-body">
                <h2 class="thin text-center">Edytuj swoje dane</h2>
                <hr>

                <?php if ($_smarty_tpl->tpl_vars['msgs']->value->isMessage()) {?>
                    <div class="messages bottom-margin">
                        <ul>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getMessages(), 'msg');
$_smarty_tpl->tpl_vars['msg']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['msg']->value) {
$_smarty_tpl->tpl_vars['msg']->do_else = false;
?>
                                <li class="msg <?php if ($_smarty_tpl->tpl_vars['msg']->value->isError()) {?>error<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isWarning()) {?>warning<?php }?> <?php if ($_smarty_tpl->tpl_vars['msg']->value->isInfo()) {?>info<?php }?>"><?php echo $_smarty_tpl->tpl_vars['msg']->value->text;?>
</li>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </ul>
                    </div>
                <?php }?>

                <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
zapiszEdycjeProfilu">
                    <div class="form-group">
                        <label for="imie">Imię:</label>
                        <input type="text" class="form-control" id="imie" name="imie" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->imie;?>
">
                    </div>
                    <div class="form-group">
                        <label for="nazwisko">Nazwisko:</label>
                        <input type="text" class="form-control" id="nazwisko" name="nazwisko" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->nazwisko;?>
">
                    </div>
                    <div class="form-group">
                        <label for="adres">Adres:</label>
                        <select class="form-control" id="adres" name="adres">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['addresses']->value, 'address');
$_smarty_tpl->tpl_vars['address']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['address']->value) {
$_smarty_tpl->tpl_vars['address']->do_else = false;
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['address']->value['id_adresu_dostawy'];?>
" <?php if ($_smarty_tpl->tpl_vars['form']->value->id_adresu == $_smarty_tpl->tpl_vars['address']->value['id_adresu_dostawy']) {?>selected<?php }?>>
                                    <?php echo $_smarty_tpl->tpl_vars['address']->value['kraj'];?>
, <?php echo $_smarty_tpl->tpl_vars['address']->value['miejscowosc'];?>
, <?php echo $_smarty_tpl->tpl_vars['address']->value['ulica_i_lokal'];?>

                                </option>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Zapisz zmiany</button>
                    <input type="hidden" name="id" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->id;?>
">
                </form>

               <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_url;?>
dodajAdres">
                    <div class="form-group">
                        <label for="kraj">Kraj:</label>
                        <input type="text" class="form-control" id="kraj" name="kraj" value="<?php echo $_smarty_tpl->tpl_vars['addressForm']->value->kraj;?>
">
                    </div>
                    <div class="form-group">
                        <label for="miejscowosc">Miejscowość:</label>
                        <input type="text" class="form-control" id="miejscowosc" name="miejscowosc" value="<?php echo $_smarty_tpl->tpl_vars['addressForm']->value->miejscowosc;?>
">
                    </div>
                    <div class="form-group">
                        <label for="ulica_i_lokal">Ulica i numer lokalu:</label>
                        <input type="text" class="form-control" id="ulica_i_lokal" name="ulica_i_lokal" value="<?php echo $_smarty_tpl->tpl_vars['addressForm']->value->ulica_i_lokal;?>
">
                    </div>
                    <button type="submit" class="btn btn-primary">Dodaj adres</button>
                </form>
            </div>
        </div>
    </div>
</article>
<?php
}
}
/* {/block 'content'} */
/* {block 'messages'} */
class Block_1546255740666466fe5a1702_54538151 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'messages' => 
  array (
    0 => 'Block_1546255740666466fe5a1702_54538151',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php
}
}
/* {/block 'messages'} */
}
