<?php

namespace app\forms;

class SigninForm {
    public $firstname;
    public $lastname;
    public $username;
    public $password;
    public $confirm_password;
    public $pass;
    public $user;
}
