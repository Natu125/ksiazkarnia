<?php

namespace app\forms;

class AddressForm {
    public $kraj;
    public $miejscowosc;
    public $ulica_i_lokal;
}
?>