<?php

namespace app\forms;

class ProductForm {
    public $id_produktu;
    public $nazwa;
    public $cena;
    public $opis;
    public $dostepnosc;
    public $obrazek;
    public $id_autora;
}