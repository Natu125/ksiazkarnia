<?php

namespace app\forms;

class CatalogForm {
    public $id_katalogu;
    public $id_roli;
    public $id_uzytkownika;
    public $id_kto_dodal;
}