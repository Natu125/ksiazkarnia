<?php

namespace app\forms;

class PanelPracForm {
    public $firstname;
    public $lastname;
    public $username;
    public $password;
    public $confirm_password;
}
