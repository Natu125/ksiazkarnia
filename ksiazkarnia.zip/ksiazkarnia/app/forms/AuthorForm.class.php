<?php

namespace app\forms;

class AuthorForm {
    public $id_autora;
    public $imie;
    public $nazwisko;
}