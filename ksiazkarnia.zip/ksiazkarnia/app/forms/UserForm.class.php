<?php

namespace app\forms;

class UserForm {
    public $id_uzytkownika;
    public $imie;
    public $nazwisko;
    public $email;
    public $haslo;
    public $kraj;
    public $miejscowosc;
    public $ulica_i_lokal;
    public $id_kto_dodal;
}