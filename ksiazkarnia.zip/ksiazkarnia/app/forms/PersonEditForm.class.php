<?php

namespace app\forms;

class PersonEditForm {
    public $id;
    public $imie;
    public $nazwisko;
    public $adres = ''; 
    public $kraj = ''; // Dodajemy nowe pola adresu
    public $miejscowosc = '';
    public $ulica_i_lokal = '';
}
?>