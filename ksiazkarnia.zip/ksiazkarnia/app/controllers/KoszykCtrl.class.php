<?php

namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;

class KoszykCtrl {

    public function action_koszyk() {

        $pdo = App::getDB();
        $id_klienta = $_SESSION['user_id'];
        $user = $pdo->get("uzytkownik", "*", ["id_uzytkownika" => $id_klienta]);

        // Sprawdzenie czy użytkownik ma przypisany adres
        $has_address = !is_null($user['id_adresu']);

        
        $query = $pdo->select("produkt", [
            "[>]autor" => ["id_autora" => "id_autora"]
        ], [
            "produkt.id_produktu(id)",
            "produkt.nazwa",
            "produkt.cena",
            "produkt.opis",
            "produkt.dostepnosc",
            "autor.imie",
            "autor.nazwisko"
        ]);

        
        $products = [];
        foreach ($query as $row) {
            $products[$row['id']] = [
                'id' => $row['id'],
                'name' => $row['nazwa'],
                'price' => $row['cena'],
                'des' => $row['opis'],
                'availability' => $row['dostepnosc'],
                'author_first_name' => $row['imie'],
                'author_last_name' => $row['nazwisko']
            ];
        }

        $cart_items = [];
        $total_price = 0;

        if (isset($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $product_id => $quantity) {
                if (isset($products[$product_id])) {
                    $product = $products[$product_id];
                    $product['quantity'] = $quantity > 0 ? $quantity : 1;
                    $product['total_price'] = $product['price'] * $product['quantity'];
                    $cart_items[] = $product;
                    $total_price += $product['total_price'];
                }
            }
        }

        // Debugowanie: sprawdzenie zawartości zmiennej $cart_items
        error_log(print_r($cart_items, true));

        App::getSmarty()->assign('cart_items', $cart_items);
        App::getSmarty()->assign('total_price', $total_price);
        App::getSmarty()->assign('has_address', $has_address);
        App::getSmarty()->assign("value", "../app/views/templates/Domainer/"); 
        App::getSmarty()->display("templates/Domainer/koszyk.tpl");
    }

    public function action_usunzkoszyk() {

      

        $product_id = $_POST['product_id'] ?? null;

        if ($product_id && isset($_SESSION['cart'])) {
            if (isset($_SESSION['cart'][$product_id])) {
                unset($_SESSION['cart'][$product_id]);
            }
        }

        header("Location: " . App::getConf()->action_url . "koszyk");
        exit();
    }

    public function action_ustalilosc() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $product_id = $_POST['product_id'];
            $quantity = (int)$_POST['quantity'];
    
            if ($quantity < 1) {
                $quantity = 1;
            }
    
            // Sprawdzenie dostępności produktu
            $product = App::getDB()->get("produkt", ["dostepnosc"], ["id_produktu" => $product_id]);
    
            if ($product['dostepnosc'] < $quantity) {
                Utils::addErrorMessage('Nie możesz zamówić więcej niż ' . $product['dostepnosc'] . ' sztuk produktu.');
                header('Location: ' . App::getConf()->action_url . 'koszyk');
                exit();
            }
    
            if (isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id] = $quantity;
            }
        }
    
        header('Location: ' . App::getConf()->action_url . 'koszyk');
        exit();
    }

    public function action_zlozzamowienie() {
        $database = App::getDB();
    
        try {
            $id_klienta = $_SESSION['user_id'];
            $user = $database->get("uzytkownik", "*", ["id_uzytkownika" => $id_klienta]);
    
            // Sprawdzenie czy użytkownik ma przypisany adres
            if (is_null($user['id_adresu'])) {
                Utils::addErrorMessage('Nie możesz złożyć zamówienia, ponieważ nie masz przypisanego adresu dostawy.');
                header('Location: ' . App::getConf()->action_url . 'koszyk');
                exit();
            }
    
            $database->pdo->beginTransaction();
    
            $total_price = 0;
    
            // Sprawdzenie dostępności produktów i obliczenie całkowitej kwoty zamówienia
            if (isset($_SESSION['cart'])) {
                foreach ($_SESSION['cart'] as $product_id => $quantity) {
                    $stmt = $database->get("produkt", ["cena", "dostepnosc"], ["id_produktu" => $product_id]);
    
                    if ($stmt['dostepnosc'] < $quantity) {
                        $database->pdo->rollBack();
                        Utils::addErrorMessage('Nie możesz zamówić więcej niż ' . $stmt['dostepnosc'] . ' sztuk produktu.');
                        header('Location: ' . App::getConf()->action_url . 'koszyk');
                        exit();
                    }
    
                    $total_price += $stmt["cena"] * $quantity;
                }
            }
    
            // Wstawienie rekordu do tabeli 'zamowienie'
            $database->insert('zamowienie', [
                'id_adresu_dostawy' => $user['id_adresu'],
                'id_klienta' => $id_klienta,
                'suma' => $total_price
            ]);
            $id_zamowienia = $database->id();
    
            // Wstawienie rekordów do tabeli 'zamowienie_produkt' dla każdego produktu w koszyku
            if (isset($_SESSION['cart'])) {
                foreach ($_SESSION['cart'] as $product_id => $quantity) {
                    $stmt = $database->get("produkt", ["cena"], ["id_produktu" => $product_id]);
                    $amount = $stmt["cena"] * $quantity;
    
                    $database->insert('zamowienie_produkt', [
                        'ilosc' => $quantity,
                        'id_zamowienia' => $id_zamowienia,
                        'id_produktu' => $product_id,
                        'kwota' => $amount
                    ]);
    
                    // Zaktualizowanie dostępności produktu
                    $database->update("produkt", [
                        "dostepnosc[-]" => $quantity
                    ], [
                        "id_produktu" => $product_id
                    ]);
                }
            }
    
            $database->pdo->commit();
    
            // Usunięcie zawartości koszyka po złożeniu zamówienia
            unset($_SESSION['cart']);
    
            App::getRouter()->redirectTo('zamowienieShow');
    
        } catch (\PDOException $e) {
            $database->pdo->rollBack();
            Utils::addErrorMessage('Database Error: ' . $e->getMessage());
            header("Location: " . App::getConf()->action_url . "koszyk");
            exit();
        }
    }

    public function action_zamowienieShow() {
        
        App::getSmarty()->assign("infos","Pomyślnie złożono zamówienie");
        App::getSmarty()->assign("value","../app/views/templates/Domainer/");
        App::getSmarty()->display("templates/Domainer/infos.tpl");
    }
}