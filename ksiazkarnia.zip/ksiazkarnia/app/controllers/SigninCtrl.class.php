<?php


namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;
use app\forms\SigninForm;

class SigninCtrl {

    private $form;

    public function __construct() {
        $this->form = new SigninForm();
    }

    public function validate() {
        $this->form->username = ParamUtils::getFromRequest('username');
        $this->form->password = ParamUtils::getFromRequest('password');

        if (!isset($this->form->username) || !isset($this->form->password)) {
            return false;
        }

        if (empty($this->form->username)) {
            Utils::addErrorMessage('Nie podano emaila');
        }
        if (empty($this->form->password)) {
            Utils::addErrorMessage('Nie podano hasła');
        }

        if (App::getMessages()->isError()) {
            return false;
        }

        return true;
    }

    public function action_signin() {
        if ($this->validate()) {
            $user = App::getDB()->get("uzytkownik", "*", [
                "email" => $this->form->username
            ]);
            
            if ($user && password_verify($this->form->password, $user['haslo'])) {
                $_SESSION['user_id'] = $user['id_uzytkownika'];

                $role = App::getDB()->get("katalog", "id_roli", [
                    "id_uzytkownika" => $user['id_uzytkownika']
                ]);

                if (!$role) {
                    Utils::addErrorMessage('Nie masz przypisanej żadnej roli. Skontaktuj się z administratorem.');
                    $this->generateView();
                    return;
                }

                switch ($role) {
                    case 1:
                        RoleUtils::addRole('admin');
                        break;
                    case 2:
                        RoleUtils::addRole('pracownik');
                        break;
                    case 3:
                        RoleUtils::addRole('user');
                        break;
                    default:
                        Utils::addErrorMessage('Niepoprawny login lub hasło');
                        $this->generateView();
                        return;
                }

                Utils::addInfoMessage('Logowanie zakończone sukcesem.');
                App::getSmarty()->assign("infos", "Logowanie zakończone sukcesem");
                App::getSmarty()->assign("value", "../app/views/templates/Domainer/");
                App::getSmarty()->display("templates/Domainer/infos.tpl");
            } else {
                Utils::addErrorMessage('Nieprawidłowy email lub hasło.');
                $this->generateView();
            }
        } else {
            $this->generateView();
        }
    }

    public function action_signout() {
        // 1. zakończenie sesji
        session_destroy();
        // 2. idź na stronę główną - system automatycznie przekieruje do strony logowania
        App::getRouter()->redirectTo('main');
    }

    public function generateView() {
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->assign("value","../app/views/templates/Domainer/");
        App::getSmarty()->display("templates/Domainer/signin.tpl");
    }


    public function action_signinShow() {
        $this->generateView();
    }
}
