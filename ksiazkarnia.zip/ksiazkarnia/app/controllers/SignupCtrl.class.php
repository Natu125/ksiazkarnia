<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\Message;
use core\ParamUtils;
use core\Validator;
use app\forms\SignupForm;

class SignupCtrl {

    private $form;

    public function __construct() {
        // Stworzenie potrzebnych obiektów
        $this->form = new SignupForm();
    }

    public function validate() {
        // Pobranie danych z formularza
        $this->form->firstname = ParamUtils::getFromRequest('firstname');
        $this->form->lastname = ParamUtils::getFromRequest('lastname');
        $this->form->username = ParamUtils::getFromRequest('username');
        $this->form->password = ParamUtils::getFromRequest('password');
        $this->form->confirm_password = ParamUtils::getFromRequest('confirm_password');

        // Walidacja danych
        if (!isset($this->form->firstname) || !isset($this->form->lastname) || !isset($this->form->username) || !isset($this->form->password) || !isset($this->form->confirm_password)) {
            return false;
        }

        // if (empty($this->form->firstname)) {
        //     Utils::addErrorMessage('Nie podano imienia');
        // }
        // if (empty($this->form->lastname)) {
        //     Utils::addErrorMessage('Nie podano nazwiska');
        // }
        // if (empty($this->form->username)) {
        //     Utils::addErrorMessage('Nie podano emaila');
        // }
        // if (empty($this->form->password)) {
        //     Utils::addErrorMessage('Nie podano hasła');
        // }
        // if (empty($this->form->confirm_password)) {
        //     Utils::addErrorMessage('Nie potwierdzono hasła');
        // }
        // if ($this->form->password !== $this->form->confirm_password) {
        //     Utils::addErrorMessage('Hasła nie są zgodne');
        // }
        

        //Sprawdzenie unikalności użytkownika 
        
        if (App::getDB()->has("uzytkownik", ["email" => $this->form->username])) {
            Utils::addErrorMessage('Użytkownik o podanym emailu już istnieje');
            return false;
        }

        $v = new Validator();
        $this->form->firstname = $v->validateFromRequest("firstname", [
          'trim' => true,
          'required' => true,
          'required_message' => 'Imię jest wymagane',
          'min_length' => 3,
          'max_length' => 30,
          'validator_message' => 'Imię powinno mieścić się pomiędzy 3 i 30 znakami',
        ]);
        
        $this->form->lastname = $v->validateFromRequest('lastname', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Nazwisko jest wymagane',
            'min_length' => 3,
            'max_length' => 30,
            'validator_message' => 'Nazwisko powinno mieścić się pomiędzy 3 i 30 znakami'
        ]);

        $this->form->username = $v->validateFromRequest('username', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Email jest wymagany',
            'email' => true,
            'validator_message' => 'Podaj poprawny adres email'
        ]);

        $this->form->password = $v->validateFromRequest('password', [
            'trim' => true,
            'required' => true,
            'required_message' => 'Hasło jest wymagane',
            'min_length' => 6,
            'validator_message' => 'Hasło powinno mieć co najmniej 6 znaków'
        ]);

        if ($this->form->password !== $this->form->confirm_password) {
            Utils::addErrorMessage('Hasła nie są zgodne');
        }    
        if (App::getMessages()->isError()) {
            return false;
        }




        return !App::getMessages()->isError();
    }

    public function action_signup() {
        if ($this->validate()) {
            // Rejestracja zakończona sukcesem - dodaj użytkownika do bazy danych
            App::getDB()->insert("uzytkownik", [
                "imie" => $this->form->firstname,
                "nazwisko" => $this->form->lastname,
                "email" => $this->form->username,
                "haslo" => password_hash($this->form->password, PASSWORD_DEFAULT),
                "id_kto_zarejestrowal" => null 
            ]);

            // Pobierz id_użytkownika właśnie zarejestrowanego użytkownika
            $lastUserId = App::getDB()->id();
            App::getDB()->update("uzytkownik", [
                "id_kto_zarejestrowal" => $lastUserId
            ], [
                "id_uzytkownika" => $lastUserId
            ]);

            App::getDB()->insert("katalog", [
                "id_uzytkownika" => $lastUserId,
                "id_roli" => 3,
                "id_kto_dodal" => $lastUserId,
            ]);



            App::getRouter()->redirectTo('signupShow');
        } else {
            // Błędy w formularzu - wyświetl stronę rejestracji
            $this->generateView();
        }
    }

    public function generateView() {
        App::getSmarty()->assign('form', $this->form);
        App::getSmarty()->assign("value","../app/views/templates/Domainer/");
        App::getSmarty()->display("templates/Domainer/signup.tpl");
    }

    public function action_signupShow() {
        
        App::getSmarty()->assign("infos","Rejestracja zakończona sukcesem");
        App::getSmarty()->assign("value","../app/views/templates/Domainer/");
        App::getSmarty()->display("templates/Domainer/infos.tpl");
    }
}

