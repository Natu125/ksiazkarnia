<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use app\forms\PersonEditForm;
use app\forms\AddressForm;

class ProfilCtrl {
  
    private $form; // dane formularza
    private $addressForm; // dane formularza adresu

    public function __construct() {
        $this->form = new PersonEditForm();
        $this->addressForm = new AddressForm();
    }

    public function action_profil() {
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
        }
    
        // Pobranie danych użytkownika
        $user = App::getDB()->get("uzytkownik", "*", [
            "id_uzytkownika" => $userId
        ]);
    
        // Pobranie szczegółów adresu
        if ($user['id_adresu']) {
            $address = App::getDB()->get("adres_dostawy", [
                "kraj",
                "miejscowosc",
                "ulica_i_lokal"
            ], [
                "id_adresu_dostawy" => $user['id_adresu']
            ]);
    
            App::getSmarty()->assign("kraj", $address['kraj']);
            App::getSmarty()->assign("miejscowosc", $address['miejscowosc']);
            App::getSmarty()->assign("ulica_i_lokal", $address['ulica_i_lokal']);
        }
    
        App::getSmarty()->assign("imie", $user['imie']);
        App::getSmarty()->assign("nazwisko", $user['nazwisko']);
        App::getSmarty()->assign("email", $user['email']);
    
        // Pobieranie zamówień użytkownika
        $orders = App::getDB()->select("zamowienie", [
            "[>]zamowienie_produkt" => ["id_zamowienia" => "id_zamowienia"],
            "[>]produkt" => ["zamowienie_produkt.id_produktu" => "id_produktu"]
        ], [
            "zamowienie.id_zamowienia",
            "zamowienie.data",
            "zamowienie.suma",
            "zamowienie_produkt.id_z_p",
            "zamowienie_produkt.ilosc",
            "zamowienie_produkt.kwota",
            "produkt.nazwa",
            "produkt.cena"
        ], [
            "zamowienie.id_klienta" => $userId
        ]);
    
        $grouped_orders = [];
        foreach ($orders as $order) {
            if (!isset($grouped_orders[$order['id_zamowienia']])) {
                $grouped_orders[$order['id_zamowienia']] = [
                    'id_zamowienia' => $order['id_zamowienia'],
                    'data' => $order['data'],
                    'suma' => $order['suma'],
                    'produkty' => []
                ];
            }
            $grouped_orders[$order['id_zamowienia']]['produkty'][] = [
                'nazwa' => $order['nazwa'],
                'cena' => $order['cena'],
                'ilosc' => $order['ilosc'],
                'kwota' => $order['kwota']
            ];
        }
    
        App::getSmarty()->assign("orders", $grouped_orders);
        App::getSmarty()->assign("value", "../app/views/templates/Domainer/");
        App::getSmarty()->display("templates/Domainer/profil.tpl");
    }

    public function action_edycjaprofilu() {
        $this->form->id = $_SESSION['user_id']; // ID użytkownika z sesji
        $this->form->imie = ParamUtils::getFromRequest('imie');
        $this->form->nazwisko = ParamUtils::getFromRequest('nazwisko');
        $this->form->id_adresu = ParamUtils::getFromRequest('adres');
    
        $this->prepareAddressSelection();
    
        App::getSmarty()->assign("form", $this->form);
        App::getSmarty()->assign("addressForm", $this->addressForm);
        App::getSmarty()->assign("value", "../app/views/templates/Domainer/");
        App::getSmarty()->display("templates/Domainer/edycjaprofilu.tpl");
    }

    public function action_zapiszEdycjeProfilu() {
        // Walidacja formularza
        $this->form->id = $_SESSION['user_id']; // ID użytkownika z sesji
        $this->form->imie = ParamUtils::getFromRequest('imie');
        $this->form->nazwisko = ParamUtils::getFromRequest('nazwisko');
        $this->form->id_adresu = ParamUtils::getFromRequest('adres');
    
        if (!$this->validateSave()) {
            // Jeśli walidacja się nie powiodła, wyświetl formularz edycji profilu
            $this->prepareAddressSelection();
            App::getSmarty()->assign("form", $this->form);
            App::getSmarty()->assign("addressForm", $this->addressForm);
            App::getSmarty()->assign("value", "../app/views/templates/Domainer/");
            App::getSmarty()->display("templates/Domainer/edycjaprofilu.tpl");
            return;
        }
    
        try {
            // Zapisz zmiany w bazie danych
            App::getDB()->update("uzytkownik", [
                "imie" => $this->form->imie,
                "nazwisko" => $this->form->nazwisko,
                "id_adresu" => $this->form->id_adresu // Zapisujemy id_adresu
            ], [
                "id_uzytkownika" => $this->form->id
            ]);
    
            Utils::addInfoMessage('Pomyślnie zaktualizowano dane.');
    
        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas zapisu do bazy danych: ' . $e->getMessage());
        }
    
        // Po udanej edycji profilu, przekieruj użytkownika z powrotem do profilu
        header('Location: ' . App::getConf()->action_url . 'profil');
        exit();
    }

    public function validateSave() {
        // Walidacja danych
        if (empty(trim($this->form->imie))) {
            Utils::addErrorMessage('Wprowadź imię');
        }
        if (empty(trim($this->form->nazwisko))) {
            Utils::addErrorMessage('Wprowadź nazwisko');
        }
        if (empty($this->form->id_adresu)) {
            Utils::addErrorMessage('Wybierz adres');
        }
    
        return !App::getMessages()->isError();
    }

    public function action_dodajAdres() {
        // Przypisanie danych z formularza do obiektu addressForm
        $this->addressForm->kraj = ParamUtils::getFromRequest('kraj');
        $this->addressForm->miejscowosc = ParamUtils::getFromRequest('miejscowosc');
        $this->addressForm->ulica_i_lokal = ParamUtils::getFromRequest('ulica_i_lokal');
    
        // Walidacja formularza adresu
        if (!$this->validateAddressForm()) {
            // Jeśli walidacja się nie powiodła, wyświetl formularz dodawania adresu
            $this->prepareAddressSelection();
            App::getSmarty()->assign("addressForm", $this->addressForm);
            App::getSmarty()->assign("form", $this->form);
            App::getSmarty()->assign("value", "../app/views/templates/Domainer/");
            App::getSmarty()->display("templates/Domainer/edycjaprofilu.tpl");
            return;
        }
    
        // Jeśli walidacja się powiodła, możemy kontynuować logikę dodawania adresu
        // Pobierz ID użytkownika z sesji
        $userId = $_SESSION['user_id'];
    
        try {
            // Dodaj nowy adres do tabeli "adres_dostawy"
            App::getDB()->insert("adres_dostawy", [
                "kraj" => $this->addressForm->kraj,
                "miejscowosc" => $this->addressForm->miejscowosc,
                "ulica_i_lokal" => $this->addressForm->ulica_i_lokal,
                "id_uzytkownika" => $userId,
                "id_kto_dodal" => $userId // Ustawiamy ID aktualnie zalogowanego użytkownika
            ]);
    
            Utils::addInfoMessage('Pomyślnie dodano nowy adres.');
    
        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas dodawania adresu.');
        }
    
        // Po dodaniu adresu, przekieruj użytkownika z powrotem do profilu
        header('Location: ' . App::getConf()->action_url . 'profil');
        exit();
    }

    public function validateAddressForm() {
        // Walidacja danych formularza adresu
        if (empty(trim($this->addressForm->kraj))) {
            Utils::addErrorMessage('Wprowadź kraj');
        }
        if (empty(trim($this->addressForm->miejscowosc))) {
            Utils::addErrorMessage('Wprowadź miejscowość');
        }
        if (empty(trim($this->addressForm->ulica_i_lokal))) {
            Utils::addErrorMessage('Wprowadź ulicę i numer lokalu');
        }
    
        return !App::getMessages()->isError();
    }

    private function prepareAddressSelection() {
        $userId = $_SESSION['user_id'];
        $addresses = App::getDB()->select("adres_dostawy", [
            "id_adresu_dostawy",
            "kraj",
            "miejscowosc",
            "ulica_i_lokal"
        ], [
            "id_uzytkownika" => $userId
        ]);
    
        App::getSmarty()->assign("addresses", $addresses);
    }
}

?>