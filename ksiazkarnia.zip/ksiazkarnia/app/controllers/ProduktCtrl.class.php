<?php

namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;

class ProduktCtrl {
 
    public function action_produkt() {
        $id_produktu = isset($_GET['produktid']) ? $_GET['produktid'] : '';

        if ($id_produktu) {
            $produkt = App::getDB()->get("produkt", [
                "[>]autor" => ["id_autora" => "id_autora"]
            ], [
                "produkt.id_produktu",
                "produkt.nazwa(nazwa_produktu)",
                "produkt.cena",
                "produkt.opis",
                "produkt.dostepnosc",
                "produkt.obrazek",
                "autor.imie",
                "autor.nazwisko"
            ], [
                "produkt.id_produktu" => $id_produktu
            ]);

            if ($produkt) {
                App::getSmarty()->assign('id_produktu', $produkt['id_produktu']);
                App::getSmarty()->assign('nazwa_produktu', $produkt['nazwa_produktu']);
                App::getSmarty()->assign('cena_produktu', $produkt['cena']);
                App::getSmarty()->assign('opis_produktu', $produkt['opis']);
                App::getSmarty()->assign('dostepnosc', $produkt['dostepnosc']);
                App::getSmarty()->assign('imie_autora', $produkt['imie']);
                App::getSmarty()->assign('nazwisko_autora', $produkt['nazwisko']);
                App::getSmarty()->assign('obrazek', $produkt['obrazek']);
            }
        }

        App::getSmarty()->assign("value", "../app/views/templates/Domainer/");
        App::getSmarty()->display("templates/Domainer/produkt.tpl");
    }

    public function action_dodajprodukt() {
        $product_id = $_POST['product_id'] ?? null;

        if ($product_id) {
            if (!isset($_SESSION['cart'])) {
                $_SESSION['cart'] = [];
            }
            if (isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id]++;
            } else {
                $_SESSION['cart'][$product_id] = 1;
            }
        }

        header("Location: " . App::getConf()->action_url . "koszyk");
        exit();
    }
}
