<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use app\forms\ProductForm;
use app\forms\AuthorForm;

class PanelPracCtrl {

    private $productForm; // formularz produktu
    private $authorForm;  // formularz autora

    public function __construct() {
        $this->productForm = new ProductForm();
        $this->authorForm = new AuthorForm();
    }

    public function action_panelPrac() {
        // Pobierz produkty
        $products = App::getDB()->select("produkt", "*");

        // Pobierz autorów
        $authors = App::getDB()->select("autor", "*");

        App::getSmarty()->assign("products", $products);
        App::getSmarty()->assign("authors", $authors);
        App::getSmarty()->assign("value", "../app/views/templates/Domainer/");
        App::getSmarty()->display("templates/Domainer/panelprac.tpl");
    }

    public function action_dodajProdukt() {
        // Przypisanie danych z formularza do obiektu productForm
        $this->productForm->nazwa = ParamUtils::getFromRequest('nazwa');
        $this->productForm->cena = ParamUtils::getFromRequest('cena');
        $this->productForm->opis = ParamUtils::getFromRequest('opis');
        $this->productForm->dostepnosc = ParamUtils::getFromRequest('dostepnosc');
        $this->productForm->obrazek = ParamUtils::getFromRequest('obrazek');
        $this->productForm->id_autora = ParamUtils::getFromRequest('id_autora');

        // Walidacja formularza produktu
        if (!$this->validateProductForm()) {
            // Jeśli walidacja się nie powiodła, wyświetl panel administracyjny
            header('Location: ' . App::getConf()->action_url . 'panelPrac');
            exit();
            return;
        }

        try {
            // Dodaj nowy produkt do tabeli "produkt"
            App::getDB()->insert("produkt", [
                "nazwa" => $this->productForm->nazwa,
                "cena" => $this->productForm->cena,
                "opis" => $this->productForm->opis,
                "dostepnosc" => $this->productForm->dostepnosc,
                "obrazek" => $this->productForm->obrazek,
                "id_autora" => $this->productForm->id_autora
            ]);

            Utils::addInfoMessage('Pomyślnie dodano nowy produkt.');

        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas dodawania produktu.');
        }

        // Po dodaniu produktu, przekieruj użytkownika z powrotem do panelu administracyjnego
        header('Location: ' . App::getConf()->action_url . 'panelPrac');
        exit();
    }

    public function action_usunProdukt() {
        $productId = ParamUtils::getFromRequest('id_produktu');

        try {
            // Usuń produkt z tabeli "produkt"
            App::getDB()->delete("produkt", [
                "id_produktu" => $productId
            ]);

            Utils::addInfoMessage('Pomyślnie usunięto produkt.');

        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas usuwania produktu.');
        }

        // Po usunięciu produktu, przekieruj użytkownika z powrotem do panelu administracyjnego
        header('Location: ' . App::getConf()->action_url . 'panelPrac');
        exit();
    }

    
    public function action_dodajAutora() {
        $this->authorForm->imie = ParamUtils::getFromRequest('imie');
        $this->authorForm->nazwisko = ParamUtils::getFromRequest('nazwisko');

        if (!$this->validateAuthorForm()) {
            header('Location: ' . App::getConf()->action_url . 'panelPrac');
            exit();
            return;
        }

        try {
            App::getDB()->insert("autor", [
                "imie" => $this->authorForm->imie,
                "nazwisko" => $this->authorForm->nazwisko
            ]);

            Utils::addInfoMessage('Pomyślnie dodano nowego autora.');

        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas dodawania autora.');
        }

        header('Location: ' . App::getConf()->action_url . 'panelPrac');
        exit();
    }

    

    public function validateProductForm() {
        if (empty(trim($this->productForm->nazwa))) {
            Utils::addErrorMessage('Wprowadź nazwę produktu');
        }
        if (empty(trim($this->productForm->cena))) {
            Utils::addErrorMessage('Wprowadź cenę produktu');
        }
        if (empty(trim($this->productForm->opis))) {
            Utils::addErrorMessage('Wprowadź opis produktu');
        }
        if (empty(trim($this->productForm->dostepnosc))) {
            Utils::addErrorMessage('Wprowadź dostępność produktu');
        }
        if (empty(trim($this->productForm->obrazek))) {
            Utils::addErrorMessage('Wprowadź obrazek produktu');
        }
        if (empty($this->productForm->id_autora)) {
            Utils::addErrorMessage('Wybierz autora');
        }

        return !App::getMessages()->isError();
    }

    public function validateAuthorForm() {
        if (empty(trim($this->authorForm->imie))) {
            Utils::addErrorMessage('Wprowadź imię autora');
        }
        if (empty(trim($this->authorForm->nazwisko))) {
            Utils::addErrorMessage('Wprowadź nazwisko autora');
        }

        return !App::getMessages()->isError();
    }
}