<?php

namespace app\controllers;

use core\App;
use core\Message;
use core\Utils;
use core\RoleUtils;
use core\ParamUtils;

class MainCtrl {
 
  public function action_main() {
 
    App::getSmarty()->assign("value","../app/views/templates/Domainer/"); 


    

    $rows = App::getDB()->select("produkt", [
      "id_produktu",
      "nazwa",
      "obrazek"
  ]);
  
  App::getSmarty()->assign('elements', $rows);
  







    App::getSmarty()->display("templates/Domainer/main.tpl");
 
  }
}