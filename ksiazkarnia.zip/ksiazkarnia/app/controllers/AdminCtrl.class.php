<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use app\forms\UserForm;
use app\forms\CatalogForm;

class AdminCtrl {

    private $userForm;
    private $catalogForm;

    public function __construct() {
        $this->userForm = new UserForm();
        $this->catalogForm = new CatalogForm();
    }

    public function action_adminPanel() {
        $users = App::getDB()->select("uzytkownik", "*");
        $roles = App::getDB()->select("rola", "*");
        $catalogs = App::getDB()->select("katalog", "*");
        $addresses = App::getDB()->select("adres_dostawy", "*");

        App::getSmarty()->assign("userForm", $this->userForm);
        App::getSmarty()->assign("catalogForm", $this->catalogForm);
        App::getSmarty()->assign("users", $users);
        App::getSmarty()->assign("roles", $roles);
        App::getSmarty()->assign("catalogs", $catalogs);
        App::getSmarty()->assign("addresses", $addresses);
        App::getSmarty()->assign("currentUserId", $this->getCurrentUserId());
        App::getSmarty()->assign("value", "../app/views/templates/Domainer/");
        App::getSmarty()->display("templates/Domainer/adminPanel.tpl");
    }

    public function action_dodajUzytkownika() {
        $this->userForm->imie = ParamUtils::getFromRequest('imie');
        $this->userForm->nazwisko = ParamUtils::getFromRequest('nazwisko');
        $this->userForm->email = ParamUtils::getFromRequest('email');
        $this->userForm->haslo = ParamUtils::getFromRequest('haslo');
        $this->userForm->kraj = ParamUtils::getFromRequest('kraj');
        $this->userForm->miejscowosc = ParamUtils::getFromRequest('miejscowosc');
        $this->userForm->ulica_i_lokal = ParamUtils::getFromRequest('ulica_i_lokal');
        $this->userForm->id_kto_dodal = $this->getCurrentUserId();

        if (!$this->validateUserForm()) {
            $this->action_adminPanel();
            header('Location: ' . App::getConf()->action_url . 'adminPanel');
            exit();
            return;
        }

        try {
            App::getDB()->pdo->beginTransaction();

            // Dodajemy użytkownika bez adresu
            App::getDB()->insert("uzytkownik", [
                "imie" => $this->userForm->imie,
                "nazwisko" => $this->userForm->nazwisko,
                "email" => $this->userForm->email,
                "haslo" => password_hash($this->userForm->haslo, PASSWORD_BCRYPT),
                "data_rejestracji" => date("Y-m-d H:i:s"),
                "id_kto_zarejestrowal" => $this->userForm->id_kto_dodal,
            ]);

            // Pobierz ID nowo dodanego użytkownika
            $id_uzytkownika = App::getDB()->id();

            // Dodajemy adres z przypisanym id_uzytkownika
            App::getDB()->insert("adres_dostawy", [
                "kraj" => $this->userForm->kraj,
                "miejscowosc" => $this->userForm->miejscowosc,
                "ulica_i_lokal" => $this->userForm->ulica_i_lokal,
                "id_uzytkownika" => $id_uzytkownika,
                "id_kto_dodal" => $this->userForm->id_kto_dodal
            ]);

            // Pobierz ID nowo dodanego adresu
            $id_adresu = App::getDB()->id();

            // Zaktualizuj użytkownika o id_adresu
            App::getDB()->update("uzytkownik", [
                "id_adresu" => $id_adresu
            ], [
                "id_uzytkownika" => $id_uzytkownika
            ]);

            App::getDB()->pdo->commit();

            Utils::addInfoMessage('Pomyślnie dodano nowego użytkownika.');

        } catch (\PDOException $e) {
            App::getDB()->pdo->rollBack();
            Utils::addErrorMessage('Wystąpił błąd podczas dodawania użytkownika: ' . $e->getMessage());
        }

        $this->action_adminPanel();
        header('Location: ' . App::getConf()->action_url . 'adminPanel');
        exit();
    }

    public function action_usunUzytkownika() {
        $userId = ParamUtils::getFromRequest('id_uzytkownika');
        $currentUserId = $this->getCurrentUserId();

        if ($userId == $currentUserId) {
            Utils::addErrorMessage('Nie możesz usunąć swojego konta.');
            $this->action_adminPanel();
            header('Location: ' . App::getConf()->action_url . 'adminPanel');
            exit();
            return;
        }

        try {
            $user = App::getDB()->get("uzytkownik", "*", ["id_uzytkownika" => $userId]);

            App::getDB()->pdo->beginTransaction();

            // Usuń referencję do adresu w tabeli "uzytkownik"
            App::getDB()->update("uzytkownik", [
                "id_adresu" => null
            ], [
                "id_uzytkownika" => $userId
            ]);

            // Usuń adres użytkownika
            App::getDB()->delete("adres_dostawy", [
                "id_adresu_dostawy" => $user['id_adresu']
            ]);

            // Usuń użytkownika
            App::getDB()->delete("uzytkownik", [
                "id_uzytkownika" => $userId
            ]);

            App::getDB()->pdo->commit();

            Utils::addInfoMessage('Pomyślnie usunięto użytkownika.');

        } catch (\PDOException $e) {
            App::getDB()->pdo->rollBack();
            Utils::addErrorMessage('Wystąpił błąd podczas usuwania użytkownika: ' . $e->getMessage());
        }

        $this->action_adminPanel();
        header('Location: ' . App::getConf()->action_url . 'adminPanel');
        exit();
    }

    public function action_dodajRole() {
        $this->catalogForm->id_roli = ParamUtils::getFromRequest('id_roli');
        $this->catalogForm->id_uzytkownika = ParamUtils::getFromRequest('id_uzytkownika');
        $this->catalogForm->id_kto_dodal = $this->getCurrentUserId();

        if (!$this->validateCatalogForm()) {
            $this->action_adminPanel();
            header('Location: ' . App::getConf()->action_url . 'adminPanel');
            exit();
            return;
        }

        try {
            $existingCatalog = App::getDB()->get("katalog", "*", [
                "id_uzytkownika" => $this->catalogForm->id_uzytkownika
            ]);

            if ($existingCatalog) {
                App::getDB()->update("katalog", [
                    "id_roli" => $this->catalogForm->id_roli,
                    "id_kto_dodal" => $this->catalogForm->id_kto_dodal
                ], [
                    "id_katalogu" => $existingCatalog['id_katalogu']
                ]);
                Utils::addInfoMessage('Pomyślnie zaktualizowano rolę użytkownika.');
            } else {
                App::getDB()->insert("katalog", [
                    "id_roli" => $this->catalogForm->id_roli,
                    "id_uzytkownika" => $this->catalogForm->id_uzytkownika,
                    "id_kto_dodal" => $this->catalogForm->id_kto_dodal
                ]);
                Utils::addInfoMessage('Pomyślnie dodano rolę użytkownikowi.');
            }

        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas aktualizacji roli.');
        }

        $this->action_adminPanel();
        header('Location: ' . App::getConf()->action_url . 'adminPanel');
        exit();
    }

    public function action_usunRole() {
        $catalogId = ParamUtils::getFromRequest('id_katalogu');
        $currentUserId = $this->getCurrentUserId();

        $catalog = App::getDB()->get("katalog", "*", ["id_katalogu" => $catalogId]);

        if ($catalog['id_uzytkownika'] == $currentUserId) {
            Utils::addErrorMessage('Nie możesz usunąć swojej roli.');
            $this->action_adminPanel();
            header('Location: ' . App::getConf()->action_url . 'adminPanel');
            exit();
            return;
        }

        try {
            App::getDB()->delete("katalog", [
                "id_katalogu" => $catalogId
            ]);

            Utils::addInfoMessage('Pomyślnie usunięto rolę.');

        } catch (\PDOException $e) {
            Utils::addErrorMessage('Wystąpił błąd podczas usuwania roli.');
        }
        $this->action_adminPanel();
        header('Location: ' . App::getConf()->action_url . 'adminPanel');
        exit();
    }

    public function validateUserForm() {
        if (empty(trim($this->userForm->imie))) {
            Utils::addErrorMessage('Wprowadź imię użytkownika');
        }
        if (empty(trim($this->userForm->nazwisko))) {
            Utils::addErrorMessage('Wprowadź nazwisko użytkownika');
        }
        if (empty(trim($this->userForm->email))) {
            Utils::addErrorMessage('Wprowadź email użytkownika');
        }
        if (empty(trim($this->userForm->haslo))) {
            Utils::addErrorMessage('Wprowadź hasło użytkownika');
        }
        if (empty(trim($this->userForm->kraj))) {
            Utils::addErrorMessage('Wprowadź kraj użytkownika');
        }
        if (empty(trim($this->userForm->miejscowosc))) {
            Utils::addErrorMessage('Wprowadź miejscowość użytkownika');
        }
        if (empty(trim($this->userForm->ulica_i_lokal))) {
            Utils::addErrorMessage('Wprowadź ulicę i lokal użytkownika');
        }
    
        return !App::getMessages()->isError();
    }

    public function validateCatalogForm() {
        if (empty($this->catalogForm->id_roli)) {
            Utils::addErrorMessage('Wybierz rolę');
        }
        if (empty($this->catalogForm->id_uzytkownika)) {
            Utils::addErrorMessage('Wybierz użytkownika');
        }

        return !App::getMessages()->isError();
    }

    private function getCurrentUserId() {
        
        return $_SESSION['user_id']; 
    }
}